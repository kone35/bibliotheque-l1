# Bibliothèque L1 — PWA

Cette version est une vraie application web progressive installable sur Android.

## Fonctionnalités
- UE et ECUE du semestre 1 préchargées
- ajout/modification/suppression des UE et ECUE
- catégories Cours, TD, TP, Exercices, Examens, Documents du professeur, Autres
- ajout de vrais fichiers depuis le téléphone
- ouverture des PDF
- recherche
- export/import de sauvegarde
- fonctionnement hors ligne après installation/cache du navigateur

## Important pour les fichiers
Le navigateur mobile impose des limites de sécurité. Les fichiers importés dans cette PWA sont stockés dans le stockage local du navigateur. Ils ne sont pas automatiquement déplacés dans un dossier visible de la carte SD.

Pour une version qui copie réellement les fichiers vers un dossier choisi de la carte SD, il faut une application Android native utilisant le Storage Access Framework.

## Installation
1. Héberger ce dossier sur un site HTTPS (GitHub Pages, Netlify, etc.).
2. Ouvrir le site avec Chrome Android.
3. Choisir « Installer » / « Ajouter à l'écran d'accueil ».
4. L'application peut ensuite être utilisée comme une app.
