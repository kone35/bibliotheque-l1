const KEY="bibliotheque_l1_v3";
const seed=[
["BIC111","Biologie cellulaire",[["BIC1111","Biologie Cellulaire"],["BIC1112","Microbiologie"]]],
["SCT112","Sciences de la terre",[["SCT1121","Géologie"],["SCT1122","Pédologie"]]],
["MQL113","Mécanique quantique et liaisons chimiques",[["MQL1131","Mécanique quantique"],["MQL1132","Liaisons chimiques"]]],
["TCC114","Thermodynamique, Cinétique Chimique et réactions en solution aqueuse",[["TCC1141","Thermodynamique et cinétique chimique"],["TCC1142","Réactions en solution aqueuse"]]],
["PHY115","Physique",[["PHY1151","Mécanique et optique"],["PHY1152","Électricité"]]],
["LAE116","Langues et entrepreneuriat",[["LAE1161","Entrepreneuriat"],["LAE1162","Technique d’expression française"]]]
];
const cats=["Cours","TD","TP","Exercices","Examens","Documents du professeur","Autres"];
let data=JSON.parse(localStorage.getItem(KEY)||"null");
if(!data){data=seed.map(([code,name,ecs])=>({id:crypto.randomUUID(),code,name,ecues:ecs.map(([c,n])=>({id:crypto.randomUUID(),code:c,name:n,docs:Object.fromEntries(cats.map(x=>[x,[]]))}))}));save()}
const $=s=>document.querySelector(s); const esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function render(){
 const q=($("#search")?.value||"").toLowerCase(); let out="";
 data.forEach(ue=>{
  const matches=!q||ue.code.toLowerCase().includes(q)||ue.name.toLowerCase().includes(q)||ue.ecues.some(e=>e.code.toLowerCase().includes(q)||e.name.toLowerCase().includes(q)||Object.values(e.docs).flat().some(d=>d.name.toLowerCase().includes(q)));
  if(!matches)return;
  out+=`<div class="ue"><div class="uehead"><span class="code">${esc(ue.code)}</span><div class="title"><b>${esc(ue.name)}</b><small>${ue.ecues.length} ECUE</small></div><div class="actions"><button onclick="addEcue('${ue.id}')">＋ ECUE</button><button onclick="editUe('${ue.id}')">✏️</button><button onclick="delUe('${ue.id}')">🗑️</button></div></div><div class="ecues">`;
  ue.ecues.forEach(e=>{out+=`<div class="ecue"><span class="folder">📁</span><div class="title"><b>${esc(e.code)} — ${esc(e.name)}</b><small>${Object.values(e.docs).flat().length} document(s)</small></div><button onclick="openEcue('${ue.id}','${e.id}')">Ouvrir</button><button onclick="editEcue('${ue.id}','${e.id}')">✏️</button></div>`});
  out+="</div></div>";
 });
 $("#tree").innerHTML=out||'<div class="panel">Aucun résultat.</div>';
}
function modal(title,html){$("#modalTitle").textContent=title;$("#modalBody").innerHTML=html;$("#modal").classList.remove("hidden")}
function close(){ $("#modal").classList.add("hidden") } $("#closeModal").onclick=close;
function form(title,vals,cb){modal(title,`<div class="formrow"><label>Code</label><input id="fcode" value="${esc(vals.code||"")}"></div><div class="formrow"><label>Nom</label><input id="fname" value="${esc(vals.name||"")}"></div><button class="primary" id="ok">Enregistrer</button>`);$("#ok").onclick=()=>{cb($("#fcode").value.trim(),$("#fname").value.trim());close();save()}}
$("#addUeBtn").onclick=()=>form("Nouvelle UE",{},(c,n)=>{if(c&&n)data.push({id:crypto.randomUUID(),code:c,name:n,ecues:[]})});
function editUe(id){let u=data.find(x=>x.id===id);form("Modifier l’UE",u,(c,n)=>{u.code=c;u.name=n})}
function delUe(id){if(confirm("Supprimer cette UE et ses ECUE ?")){data=data.filter(x=>x.id!==id);save()}}
function addEcue(uid){let u=data.find(x=>x.id===uid);form("Nouvel ECUE",{},(c,n)=>{if(c&&n)u.ecues.push({id:crypto.randomUUID(),code:c,name:n,docs:Object.fromEntries(cats.map(x=>[x,[]]))})})}
function editEcue(uid,eid){let e=data.find(x=>x.id===uid).ecues.find(x=>x.id===eid);form("Modifier l’ECUE",e,(c,n)=>{e.code=c;e.name=n})}
function openEcue(uid,eid){
 let u=data.find(x=>x.id===uid), e=u.ecues.find(x=>x.id===eid);
 let html=`<p><b>${esc(e.code)} — ${esc(e.name)}</b></p>`;
 cats.forEach(cat=>{html+=`<div class="panel"><div style="display:flex;justify-content:space-between;align-items:center"><h3>${cat}</h3><button onclick="addDoc('${uid}','${eid}','${cat}')">＋ Ajouter</button></div><div id="docs-${btoa(cat).replace(/=/g,'')}">`;
 e.docs[cat].forEach((d,i)=>html+=`<div class="doc"><span>📄</span><div class="docname"><b>${esc(d.name)}</b><small>${d.type||"Document"}</small></div>${d.data?`<button onclick="openDoc('${uid}','${eid}','${cat}',${i})">Ouvrir</button>`:""}<button onclick="removeDoc('${uid}','${eid}','${cat}',${i})">🗑️</button></div>`);
 html+=`</div></div>`});
 modal(e.name,html);
}
function addDoc(uid,eid,cat){
 const inp=document.createElement("input");inp.type="file";inp.accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.jpg,.jpeg,.png";inp.onchange=()=>{const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{let e=data.find(x=>x.id===uid).ecues.find(x=>x.id===eid);e.docs[cat].push({name:f.name,type:f.type,data:r.result});save();openEcue(uid,eid)};r.readAsDataURL(f)};inp.click();
}
function openDoc(uid,eid,cat,i){const d=data.find(x=>x.id===uid).ecues.find(x=>x.id===eid).docs[cat][i];const w=window.open();if(!w)return; if(d.type==="application/pdf"||d.name.toLowerCase().endsWith(".pdf"))w.location=d.data;else{w.document.write(`<h3>${esc(d.name)}</h3><p>Ce format dépend du lecteur installé sur ton téléphone.</p><a download="${esc(d.name)}" href="${d.data}">Télécharger / ouvrir</a>`)}}
function removeDoc(uid,eid,cat,i){let e=data.find(x=>x.id===uid).ecues.find(x=>x.id===eid);if(confirm("Supprimer ce document ?")){e.docs[cat].splice(i,1);save();openEcue(uid,eid)}}
$("#search").oninput=render; $("#settingsBtn").onclick=()=>{$(".view.active").classList.remove("active");$("#settings").classList.add("active")};document.querySelectorAll("[data-home]").forEach(x=>x.onclick=()=>{$(".view.active").classList.remove("active");$("#home").classList.add("active")});
$("#exportBtn").onclick=()=>{const b=new Blob([JSON.stringify(data)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="bibliotheque-l1-sauvegarde.json";a.click()};
$("#importDataBtn").onclick=()=>$("#importData").click();$("#importData").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{data=JSON.parse(r.result);save();alert("Bibliothèque importée.")}catch{alert("Fichier invalide.")}};r.readAsText(f)};
$("#resetBtn").onclick=()=>{if(confirm("Tout effacer et remettre les UE du semestre 1 ?")){localStorage.removeItem(KEY);location.reload()}};
let deferred;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferred=e;$("#installBtn").hidden=false});$("#installBtn").onclick=async()=>{if(deferred){deferred.prompt();await deferred.userChoice;deferred=null;$("#installBtn").hidden=true}};
render();
